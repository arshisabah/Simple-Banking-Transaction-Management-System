package com.bank.util;

import com.bank.model.Account;
import com.bank.model.Customer;
import com.bank.model.Transaction;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * Since this application intentionally has no database, "Save Data" writes a
 * structured JSON snapshot of the current in-memory state to disk so the session's
 * results can be reviewed or archived outside the console.
 */
public final class FileExporter {

    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    private static final String INDENT = "  ";

    private FileExporter() {
    }

    public static Path exportSnapshot(Collection<Customer> customers,
                                       Collection<Account> accounts,
                                       List<Transaction> transactions,
                                       String outputDirectory) throws IOException {

        Path dir = Path.of(outputDirectory);
        Files.createDirectories(dir);

        Path file = dir.resolve("bank_snapshot_" + java.time.LocalDateTime.now().format(STAMP) + ".json");

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");

        sb.append(INDENT).append("\"customers\": [\n");
        writeJoined(sb, customers, FileExporter::customerJson);
        sb.append(INDENT).append("],\n");

        sb.append(INDENT).append("\"accounts\": [\n");
        writeJoined(sb, accounts, FileExporter::accountJson);
        sb.append(INDENT).append("],\n");

        sb.append(INDENT).append("\"transactions\": [\n");
        writeJoined(sb, transactions, FileExporter::transactionJson);
        sb.append(INDENT).append("]\n");

        sb.append("}\n");

        Files.writeString(file, sb.toString());
        return file;
    }

    private static <T> void writeJoined(StringBuilder sb, Collection<T> items,
                                         java.util.function.Function<T, String> toJson) {
        Iterator<T> it = items.iterator();
        while (it.hasNext()) {
            T item = it.next();
            sb.append(INDENT).append(INDENT).append(toJson.apply(item));
            if (it.hasNext()) {
                sb.append(",");
            }
            sb.append("\n");
        }
    }

    private static String customerJson(Customer c) {
        StringBuilder o = new StringBuilder("{");
        o.append("\"customerId\": ").append(quote(c.customerId())).append(", ");
        o.append("\"name\": ").append(quote(c.name())).append(", ");
        o.append("\"email\": ").append(quote(c.email())).append(", ");
        o.append("\"phone\": ").append(quote(c.phone()));
        o.append("}");
        return o.toString();
    }

    private static String accountJson(Account a) {
        StringBuilder o = new StringBuilder("{");
        o.append("\"accountNumber\": ").append(quote(a.getAccountNumber())).append(", ");
        o.append("\"customerId\": ").append(quote(a.getCustomerId())).append(", ");
        o.append("\"accountType\": ").append(quote(a.getAccountType().name())).append(", ");
        o.append("\"balance\": ").append(a.getBalance()).append(", ");
        o.append("\"status\": ").append(quote(a.getStatus().name())).append(", ");
        o.append("\"createdDate\": ").append(quote(a.getCreatedDate().toString()));
        o.append("}");
        return o.toString();
    }

    private static String transactionJson(Transaction t) {
        StringBuilder o = new StringBuilder("{");
        o.append("\"transactionId\": ").append(quote(t.transactionId())).append(", ");
        o.append("\"type\": ").append(quote(t.type().name())).append(", ");
        o.append("\"sourceAccount\": ").append(quote(t.sourceAccount())).append(", ");
        o.append("\"destinationAccount\": ").append(quote(t.destinationAccount())).append(", ");
        o.append("\"amount\": ").append(t.amount()).append(", ");
        o.append("\"dateTime\": ").append(quote(t.dateTime().toString())).append(", ");
        o.append("\"status\": ").append(quote(t.status().name()));
        o.append("}");
        return o.toString();
    }

    /** Wraps a value in quotes and escapes characters that are special in JSON strings. */
    private static String quote(String value) {
        if (value == null) {
            return "null";
        }
        StringBuilder out = new StringBuilder(value.length() + 2);
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> {
                    if (c < 0x20) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
                }
            }
        }
        out.append('"');
        return out.toString();
    }
}
