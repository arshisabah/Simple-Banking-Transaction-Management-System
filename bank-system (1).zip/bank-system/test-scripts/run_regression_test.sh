#!/bin/bash
# Runs the full scripted regression test against the compiled app and
# prints a highlighted summary of the key results.
#
# Usage: ./test-scripts/run_regression_test.sh
set -e
cd "$(dirname "$0")/.."

if [ ! -d "build" ]; then
    echo "Build not found, compiling first..."
    ./build.sh
fi

LOG="test-scripts/regression_output.log"
echo "Running full regression test... (log: $LOG)"
java -cp build com.bank.Main < test-scripts/full_regression_input.txt > "$LOG" 2>&1

echo ""
echo "=================== SUMMARY ==================="
echo ""
echo "--- Customers created ---"
grep "Customer created successfully" -A1 "$LOG" | grep "Customer\[" || true

echo ""
echo "--- Accounts opened ---"
grep "Account opened successfully" -A1 "$LOG" | grep "Account\[" || true

echo ""
echo "--- Errors triggered (should be 8) ---"
grep -o "ERROR:.*" "$LOG" || true

echo ""
echo "--- Multithreading demo result ---"
grep "Processed .* requests" "$LOG" || true
grep "Final balance for" "$LOG" || true

echo ""
echo "--- Account closures ---"
grep -E "closed successfully|Cannot close account" "$LOG" || true

echo ""
echo "--- Data export ---"
grep "Data saved to" "$LOG" || true

echo ""
echo "--- Final ACC100003 state (should show CLOSED, Balance=0.00) ---"
grep "Account\[ACC100003\]" "$LOG" | tail -1 || true

echo ""
echo "================================================="
echo "Full transcript saved to: $LOG"
echo "If every section above looks right, the app is working correctly."
